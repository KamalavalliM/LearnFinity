package com.vast.Exception;

public class UserAlreadyFoundException extends Exception{

	public UserAlreadyFoundException() {
		super();
	}

	public UserAlreadyFoundException(String message) {
		super(message);
	}
	
}
